The GeoSPARLQ implementation uses some code from the uSeekM project.
See LICENSE-uSeekM.txt for the original license.